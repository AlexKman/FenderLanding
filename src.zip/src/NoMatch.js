import React from "react";

export const NoMatch = () => (
  <div>
    <h2>No Match Found here!</h2>
  </div>
);
